"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUser = createUser;
exports.findByEmail = findByEmail;
exports.findById = findById;
exports.updateUser = updateUser;
exports.deleteUser = deleteUser;
exports.validateCredentials = validateCredentials;
const User_1 = require("../models/User");
const errorHandler_1 = require("../middleware/errorHandler");
const uuid_1 = require("uuid");
/**
 * Create a new user in DynamoDB
 */
async function createUser(userData) {
    try {
        // Hash the password
        const hashedPassword = await (0, User_1.hashPassword)(userData.password);
        // Create a new user with auto-generated ID
        const newUser = {
            id: (0, uuid_1.v4)(),
            ...userData,
            password: hashedPassword,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        // Save user to DynamoDB using the Entity
        await User_1.User.put(newUser);
        return newUser;
    }
    catch (error) {
        if (error.code === "ConditionalCheckFailedException") {
            throw new errorHandler_1.ApplicationError("User with this email already exists", 400);
        }
        throw error;
    }
}
/**
 * Find a user by email
 */
async function findByEmail(email) {
    try {
        // Query by email
        const result = await User_1.User.scan({
            filters: [{ attr: "email", eq: email }],
            limit: 1,
        });
        if (result.Items && result.Items.length > 0) {
            return result.Items[0];
        }
        return null;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Find a user by ID
 */
async function findById(id) {
    try {
        // Get by primary key
        const result = await User_1.User.get({ id });
        if (result.Item) {
            return result.Item;
        }
        return null;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Update a user
 */
async function updateUser(id, updates) {
    try {
        // First find the user to make sure it exists
        const existingUser = await findById(id);
        if (!existingUser) {
            throw new errorHandler_1.ApplicationError("User not found", 404);
        }
        // Include updatedAt in updates
        const updatedFields = {
            ...updates,
            updatedAt: new Date(),
            id: id, // Ensure ID is included for the key
        };
        // Hash password if it's being updated
        if (updates.password) {
            updatedFields.password = await (0, User_1.hashPassword)(updates.password);
        }
        // Update using the Entity
        const result = await User_1.User.update(updatedFields);
        return result.Attributes;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Delete a user
 */
async function deleteUser(id) {
    try {
        // Delete the user by ID
        await User_1.User.delete({ id });
    }
    catch (error) {
        throw error;
    }
}
/**
 * Validate user credentials
 */
async function validateCredentials(email, password) {
    try {
        const user = await findByEmail(email);
        if (!user) {
            return null;
        }
        const passwordMatch = await (0, User_1.comparePassword)(password, user.password);
        if (!passwordMatch) {
            return null;
        }
        return user;
    }
    catch (error) {
        throw error;
    }
}
