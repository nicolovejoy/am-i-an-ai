"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConversations = getConversations;
exports.getConversation = getConversation;
exports.createConversation = createConversation;
exports.addMessage = addMessage;
exports.toggleArchive = toggleArchive;
exports.deleteConversation = deleteConversation;
const Conversation_1 = require("../models/Conversation");
const errorHandler_1 = require("../middleware/errorHandler");
const uuid_1 = require("uuid");
/**
 * Get all conversations for a user
 */
async function getConversations(userId, archived) {
    try {
        let queryParams = {
            pk: `USER#${userId}`,
            beginsWith: "CONV#",
        };
        // If archived filter is provided, use GSI1
        if (archived !== undefined) {
            queryParams = {
                index: "gsi1",
                pk: `USER#${userId}`,
                beginsWith: `ARCHIVED#${archived ? "1" : "0"}#CONV#`,
            };
        }
        // Using the Entity with type assertion
        const result = await Conversation_1.Conversation.query(queryParams);
        return result.Items;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Get a conversation by ID
 */
async function getConversation(userId, id) {
    try {
        // Using the Entity with type assertion
        const result = await Conversation_1.Conversation.get({
            pk: `USER#${userId}`,
            sk: `CONV#${id}`,
        });
        if (!result.Item) {
            return null;
        }
        return result.Item;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Create a new conversation
 */
async function createConversation(userId, title, initialMessage) {
    try {
        const id = (0, uuid_1.v4)();
        const now = new Date();
        let messages = [];
        if (initialMessage) {
            messages = [
                {
                    content: initialMessage,
                    sender: "user",
                    timestamp: now,
                },
            ];
        }
        const newConversation = {
            id,
            userId,
            title,
            messages,
            lastMessageAt: now,
            isArchived: false,
            createdAt: now,
            updatedAt: now,
        };
        // Using the Entity with type assertion
        await Conversation_1.Conversation.put(newConversation);
        return newConversation;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Add a message to a conversation
 */
async function addMessage(userId, conversationId, content, sender) {
    try {
        // First get the conversation
        const conversation = await getConversation(userId, conversationId);
        if (!conversation) {
            throw new errorHandler_1.ApplicationError("Conversation not found", 404);
        }
        // Create the new message
        const message = {
            content,
            sender,
            timestamp: new Date(),
        };
        // Prepare the update
        const now = new Date();
        const messages = [...conversation.messages, message];
        // Using the Entity with type assertion
        await Conversation_1.Conversation.update({
            pk: `USER#${userId}`,
            sk: `CONV#${conversationId}`,
            messages,
            lastMessageAt: now,
            updatedAt: now,
        });
        return message;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Toggle conversation archive status
 */
async function toggleArchive(userId, conversationId, archived) {
    try {
        // Get the existing conversation
        const conversation = await getConversation(userId, conversationId);
        if (!conversation) {
            throw new errorHandler_1.ApplicationError("Conversation not found", 404);
        }
        const now = new Date();
        // Update the conversation using the Entity with type assertion
        await Conversation_1.Conversation.update({
            pk: `USER#${userId}`,
            sk: `CONV#${conversationId}`,
            isArchived: archived,
            updatedAt: now,
        });
        // Get and return the updated conversation
        const updatedConversation = await getConversation(userId, conversationId);
        if (!updatedConversation) {
            throw new errorHandler_1.ApplicationError("Conversation not found after update", 500);
        }
        return updatedConversation;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Delete a conversation
 */
async function deleteConversation(userId, conversationId) {
    try {
        // Using the Entity with type assertion
        await Conversation_1.Conversation.delete({
            pk: `USER#${userId}`,
            sk: `CONV#${conversationId}`,
        });
    }
    catch (error) {
        throw error;
    }
}
