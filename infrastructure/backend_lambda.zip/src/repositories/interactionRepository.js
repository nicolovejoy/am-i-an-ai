"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInteraction = createInteraction;
exports.findById = findById;
exports.findByUserId = findByUserId;
exports.findByAgentId = findByAgentId;
exports.updateInteraction = updateInteraction;
exports.addMessage = addMessage;
exports.updateTrustScore = updateTrustScore;
exports.deleteInteraction = deleteInteraction;
const Interaction_1 = require("../models/Interaction");
const errorHandler_1 = require("../middleware/errorHandler");
const uuid_1 = require("uuid");
/**
 * Create a new interaction in DynamoDB
 */
async function createInteraction(interactionData) {
    try {
        // Create a new interaction with auto-generated ID
        const newInteraction = {
            id: (0, uuid_1.v4)(),
            ...interactionData,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        // Save interaction to DynamoDB using the Entity with type assertion
        await Interaction_1.Interaction.put(newInteraction);
        return newInteraction;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Find an interaction by ID and user ID
 */
async function findById(id, userId) {
    try {
        // Using the Entity with type assertion
        const result = await Interaction_1.Interaction.get({
            pk: `USER#${userId}`,
            sk: `INTERACTION#${id}`,
        });
        if (result.Item) {
            return result.Item;
        }
        return null;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Get all interactions for a user
 */
async function findByUserId(userId, limit = 20, lastEvaluatedKey) {
    try {
        // Using the Entity with type assertion
        const queryParams = {
            pk: `USER#${userId}`,
            beginsWith: "INTERACTION#",
            limit,
        };
        if (lastEvaluatedKey) {
            queryParams.exclusiveStartKey = lastEvaluatedKey;
        }
        const result = await Interaction_1.Interaction.query(queryParams);
        return {
            items: result.Items,
            lastEvaluatedKey: result.LastEvaluatedKey,
        };
    }
    catch (error) {
        throw error;
    }
}
/**
 * Get all interactions for an agent
 */
async function findByAgentId(agentId, limit = 20, lastEvaluatedKey) {
    try {
        // Using the Entity with type assertion and GSI
        const queryParams = {
            index: "gsi1",
            pk: `AGENT#${agentId}`,
            beginsWith: "INTERACTION#",
            limit,
        };
        if (lastEvaluatedKey) {
            queryParams.exclusiveStartKey = lastEvaluatedKey;
        }
        const result = await Interaction_1.Interaction.query(queryParams);
        return {
            items: result.Items,
            lastEvaluatedKey: result.LastEvaluatedKey,
        };
    }
    catch (error) {
        throw error;
    }
}
/**
 * Update an interaction
 */
async function updateInteraction(id, userId, updates) {
    try {
        // Prepare update expression and attribute values
        const existingInteraction = await findById(id, userId);
        if (!existingInteraction) {
            throw new errorHandler_1.ApplicationError("Interaction not found", 404);
        }
        // Include updatedAt in updates
        const updatedFields = {
            ...updates,
            updatedAt: new Date(),
        };
        // Update in DynamoDB
        const updateParams = {
            pk: `USER#${userId}`,
            sk: `INTERACTION#${id}`,
            ...updatedFields,
        };
        await Interaction_1.Interaction.update(updateParams);
        // Return the updated interaction
        const updatedInteraction = await findById(id, userId);
        if (!updatedInteraction) {
            throw new errorHandler_1.ApplicationError("Failed to retrieve updated interaction", 500);
        }
        return updatedInteraction;
    }
    catch (error) {
        throw error;
    }
}
/**
 * Add a message to an interaction
 */
async function addMessage(id, userId, message) {
    try {
        const interaction = await findById(id, userId);
        if (!interaction) {
            throw new errorHandler_1.ApplicationError("Interaction not found", 404);
        }
        // Add the message to the messages array
        const newMessages = [...interaction.messages, message];
        // Update the interaction with the new message and last message timestamp
        return updateInteraction(id, userId, {
            messages: newMessages,
            lastMessageAt: message.timestamp,
        });
    }
    catch (error) {
        throw error;
    }
}
/**
 * Update interaction trust score
 */
async function updateTrustScore(id, userId, trustScore) {
    try {
        if (trustScore < 0 || trustScore > 100) {
            throw new errorHandler_1.ApplicationError("Trust score must be between 0 and 100", 400);
        }
        return updateInteraction(id, userId, { trustScore });
    }
    catch (error) {
        throw error;
    }
}
/**
 * Delete an interaction
 */
async function deleteInteraction(id, userId) {
    try {
        await Interaction_1.Interaction.delete({
            pk: `USER#${userId}`,
            sk: `INTERACTION#${id}`,
        });
    }
    catch (error) {
        throw error;
    }
}
