"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteConversation = exports.toggleArchive = exports.addMessage = exports.createConversation = exports.getConversation = exports.getConversations = void 0;
const errorHandler_1 = require("../middleware/errorHandler");
const conversationRepository = __importStar(require("../repositories/conversationRepository"));
/**
 * Get all conversations for the authenticated user
 * GET /api/conversations
 */
const getConversations = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        const archived = req.query.archived === "true"
            ? true
            : req.query.archived === "false"
                ? false
                : undefined;
        // Get conversations from repository
        const conversations = await conversationRepository.getConversations(userId, archived);
        res.status(200).json({
            status: "success",
            data: {
                conversations,
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getConversations = getConversations;
/**
 * Get a specific conversation by ID
 * GET /api/conversations/:id
 */
const getConversation = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        const { id } = req.params;
        // Find conversation through repository
        const conversation = await conversationRepository.getConversation(userId, id);
        if (!conversation) {
            throw new errorHandler_1.ApplicationError("Conversation not found", 404);
        }
        res.status(200).json({
            status: "success",
            data: {
                conversation,
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getConversation = getConversation;
/**
 * Create a new conversation
 * POST /api/conversations
 */
const createConversation = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        const { title, initialMessage } = req.body;
        // Create conversation through repository
        const conversation = await conversationRepository.createConversation(userId, title, initialMessage);
        res.status(201).json({
            status: "success",
            data: {
                conversation,
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.createConversation = createConversation;
/**
 * Add a message to a conversation
 * POST /api/conversations/:id/messages
 */
const addMessage = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        const { id } = req.params;
        const { content, sender } = req.body;
        // Validate sender
        if (!["user", "ai", "system"].includes(sender)) {
            throw new errorHandler_1.ApplicationError("Invalid sender type", 400);
        }
        // Add message through repository
        const message = await conversationRepository.addMessage(userId, id, content, sender);
        res.status(200).json({
            status: "success",
            data: {
                message,
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.addMessage = addMessage;
/**
 * Archive/unarchive a conversation
 * PATCH /api/conversations/:id/archive
 */
const toggleArchive = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        const { id } = req.params;
        const { archived } = req.body;
        // Toggle archive through repository
        const conversation = await conversationRepository.toggleArchive(userId, id, archived);
        res.status(200).json({
            status: "success",
            data: {
                conversation,
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.toggleArchive = toggleArchive;
/**
 * Delete a conversation
 * DELETE /api/conversations/:id
 */
const deleteConversation = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        const { id } = req.params;
        // Delete conversation through repository
        await conversationRepository.deleteConversation(userId, id);
        res.status(200).json({
            status: "success",
            message: "Conversation deleted successfully",
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteConversation = deleteConversation;
