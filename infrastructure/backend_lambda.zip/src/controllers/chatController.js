"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.chatController = void 0;
const aiService_1 = require("../services/aiService");
const zod_1 = require("zod");
// Validation schema for chat completion request
const chatCompletionSchema = zod_1.z.object({
    messages: zod_1.z.array(zod_1.z.object({
        role: zod_1.z.enum(["system", "user", "assistant"]),
        content: zod_1.z.string(),
    })),
    model: zod_1.z.string().optional(),
});
/**
 * Controller for handling chat-related API endpoints
 */
exports.chatController = {
    /**
     * Generate a chat completion response
     */
    generateChatCompletion: async (req, res, next) => {
        try {
            // Validate request body
            const validationResult = chatCompletionSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    success: false,
                    error: "Invalid request format",
                    details: validationResult.error.format(),
                });
                return;
            }
            const { messages, model } = validationResult.data;
            // Call AI service to generate response
            const response = await aiService_1.aiService.generateChatCompletion({
                messages,
                ...(model ? { model } : {}),
            });
            res.status(200).json({
                success: true,
                data: response,
            });
        }
        catch (error) {
            console.error("Chat controller error:", error);
            res.status(500).json({
                success: false,
                error: "Failed to generate chat completion",
            });
        }
    },
};
