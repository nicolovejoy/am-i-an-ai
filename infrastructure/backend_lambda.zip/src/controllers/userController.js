"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUserAccount = exports.updateUserProfile = exports.getUserProfile = void 0;
const User_1 = require("../models/User");
const errorHandler_1 = require("../middleware/errorHandler");
const userRepository = __importStar(require("../repositories/userRepository"));
/**
 * Get user profile
 * GET /api/users/profile
 */
const getUserProfile = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        if (!userId) {
            throw new errorHandler_1.ApplicationError("User ID is required", 400);
        }
        const user = await userRepository.findById(userId);
        if (!user) {
            throw new errorHandler_1.ApplicationError("User not found", 404);
        }
        res.status(200).json({
            status: "success",
            data: {
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    createdAt: user.createdAt,
                    lastLogin: user.lastLogin,
                    usageCount: user.usageCount,
                    isVerified: user.isVerified,
                },
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getUserProfile = getUserProfile;
/**
 * Update user profile
 * PUT /api/users/profile
 */
const updateUserProfile = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        if (!userId) {
            throw new errorHandler_1.ApplicationError("User ID is required", 400);
        }
        const { name, password, currentPassword } = req.body;
        // Get the user
        const user = await userRepository.findById(userId);
        if (!user) {
            throw new errorHandler_1.ApplicationError("User not found", 404);
        }
        // If password is being updated, verify current password
        if (password && currentPassword) {
            const isPasswordValid = await (0, User_1.comparePassword)(currentPassword, user.password);
            if (!isPasswordValid) {
                throw new errorHandler_1.ApplicationError("Current password is incorrect", 400);
            }
        }
        // Update user fields
        const updates = {};
        if (name)
            updates.name = name;
        if (password)
            updates.password = password;
        // Save changes
        const updatedUser = await userRepository.updateUser(userId, updates);
        res.status(200).json({
            status: "success",
            message: "Profile updated successfully",
            data: {
                user: {
                    id: updatedUser.id,
                    name: updatedUser.name,
                    email: updatedUser.email,
                },
            },
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateUserProfile = updateUserProfile;
/**
 * Delete user account
 * DELETE /api/users/account
 */
const deleteUserAccount = async (req, res, next) => {
    try {
        const userId = req.user?.id;
        if (!userId) {
            throw new errorHandler_1.ApplicationError("User ID is required", 400);
        }
        const { password } = req.body;
        // Get the user
        const user = await userRepository.findById(userId);
        if (!user) {
            throw new errorHandler_1.ApplicationError("User not found", 404);
        }
        // Verify password before deletion
        if (!password) {
            throw new errorHandler_1.ApplicationError("Password is required to delete account", 400);
        }
        const isPasswordValid = await (0, User_1.comparePassword)(password, user.password);
        if (!isPasswordValid) {
            throw new errorHandler_1.ApplicationError("Password is incorrect", 400);
        }
        // Delete the user
        await userRepository.deleteUser(userId);
        // TODO: Also delete all user data (conversations, analysis, etc.)
        res.status(200).json({
            status: "success",
            message: "Account deleted successfully",
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteUserAccount = deleteUserAccount;
