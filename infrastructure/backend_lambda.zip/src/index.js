"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const dotenv_1 = __importDefault(require("dotenv"));
const errorHandler_1 = require("./middleware/errorHandler");
const authRoutes_1 = __importDefault(require("./routes/authRoutes"));
const userRoutes_1 = __importDefault(require("./routes/userRoutes"));
const conversationRoutes_1 = __importDefault(require("./routes/conversationRoutes"));
const chatRoutes_1 = __importDefault(require("./routes/chatRoutes"));
const dynamodb_1 = require("./config/dynamodb");
// Load environment variables
dotenv_1.default.config();
// Initialize express app
const app = (0, express_1.default)();
const port = process.env.PORT || 5000;
// Check DynamoDB connection
const checkDynamoDbConnection = async () => {
    try {
        // Simple operation to check connection
        await dynamodb_1.client.config.credentials();
        console.log("DynamoDB client initialized successfully");
        return true;
    }
    catch (error) {
        console.error("DynamoDB connection error:", error);
        return false;
    }
};
// Initialize DynamoDB connection
checkDynamoDbConnection();
// Middleware
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)({
    origin: process.env.FRONTEND_URL,
    credentials: true,
}));
app.use(express_1.default.json({ limit: "1mb" }));
app.use(express_1.default.urlencoded({ extended: true }));
// Routes
app.get("/api/health", (_req, res) => {
    res.status(200).json({ status: "ok", message: "Server is running" });
});
// API Routes
app.use("/api/auth", authRoutes_1.default);
app.use("/api/users", userRoutes_1.default);
app.use("/api/conversations", conversationRoutes_1.default);
app.use("/api/chat", chatRoutes_1.default);
// 404 handler
app.use((req, res, _next) => {
    res.status(404).json({
        status: "error",
        message: `Cannot ${req.method} ${req.originalUrl}`,
    });
});
// Error handling middleware
app.use(errorHandler_1.errorHandler);
// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
    console.log(`Environment: ${process.env.NODE_ENV}`);
});
exports.default = app;
