"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.comparePassword = exports.hashPassword = void 0;
exports.createUser = createUser;
exports.findByEmail = findByEmail;
exports.findById = findById;
exports.updateUser = updateUser;
exports.deleteUser = deleteUser;
const uuid_1 = require("uuid");
const bcrypt_1 = __importDefault(require("bcrypt"));
const dynamodb_1 = require("../config/dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Utility function to hash a password
const hashPassword = async (password) => {
    const salt = await bcrypt_1.default.genSalt(12);
    return bcrypt_1.default.hash(password, salt);
};
exports.hashPassword = hashPassword;
// Utility function to compare password with hashed version
const comparePassword = async (plainPassword, hashedPassword) => {
    return bcrypt_1.default.compare(plainPassword, hashedPassword);
};
exports.comparePassword = comparePassword;
// Create a new user
async function createUser(userData) {
    const hashedPassword = await (0, exports.hashPassword)(userData.password);
    const newUser = {
        id: (0, uuid_1.v4)(),
        ...userData,
        password: hashedPassword,
        createdAt: new Date(),
        updatedAt: new Date(),
    };
    await dynamodb_1.documentClient.send(new lib_dynamodb_1.PutCommand({
        TableName: dynamodb_1.USER_TABLE,
        Item: {
            pk: `USER#${newUser.id}`,
            sk: `PROFILE#${newUser.id}`,
            ...newUser,
        },
    }));
    return newUser;
}
// Find a user by email
async function findByEmail(email) {
    const result = await dynamodb_1.documentClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: dynamodb_1.USER_TABLE,
        IndexName: "EmailIndex",
        KeyConditionExpression: "email = :email",
        ExpressionAttributeValues: {
            ":email": email,
        },
        Limit: 1,
    }));
    if (result.Items && result.Items.length > 0) {
        return result.Items[0];
    }
    return null;
}
// Find a user by ID
async function findById(id) {
    const result = await dynamodb_1.documentClient.send(new lib_dynamodb_1.GetCommand({
        TableName: dynamodb_1.USER_TABLE,
        Key: {
            pk: `USER#${id}`,
            sk: `PROFILE#${id}`,
        },
    }));
    if (result.Item) {
        return result.Item;
    }
    return null;
}
// Update a user
async function updateUser(id, updates) {
    const updateFields = {
        ...updates,
        updatedAt: new Date(),
    };
    if (updates.password) {
        updateFields.password = await (0, exports.hashPassword)(updates.password);
    }
    const updateExpressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};
    Object.entries(updateFields).forEach(([key, value]) => {
        if (key !== "id" && key !== "pk" && key !== "sk") {
            updateExpressions.push(`#${key} = :${key}`);
            expressionAttributeNames[`#${key}`] = key;
            expressionAttributeValues[`:${key}`] = value;
        }
    });
    const result = await dynamodb_1.documentClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: dynamodb_1.USER_TABLE,
        Key: {
            pk: `USER#${id}`,
            sk: `PROFILE#${id}`,
        },
        UpdateExpression: `SET ${updateExpressions.join(", ")}`,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: "ALL_NEW",
    }));
    return result.Attributes;
}
// Delete a user
async function deleteUser(id) {
    await dynamodb_1.documentClient.send(new lib_dynamodb_1.DeleteCommand({
        TableName: dynamodb_1.USER_TABLE,
        Key: {
            pk: `USER#${id}`,
            sk: `PROFILE#${id}`,
        },
    }));
}
