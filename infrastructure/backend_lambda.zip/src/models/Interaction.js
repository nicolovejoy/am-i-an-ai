"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Interaction = void 0;
const dynamodb_toolbox_1 = require("dynamodb-toolbox");
const dynamodb_1 = require("../config/dynamodb");
const uuid_1 = require("uuid");
// Create an Interaction entity for DynamoDB
exports.Interaction = new dynamodb_toolbox_1.Entity({
    table: dynamodb_1.AnalysisTable,
    name: "Interaction",
    attributes: {
        pk: { partitionKey: true, default: (data) => `USER#${data.userId}` },
        sk: { sortKey: true, default: (data) => `INTERACTION#${data.id}` },
        gsi1pk: { default: (data) => `AGENT#${data.agentId}` },
        gsi1sk: { default: (data) => `INTERACTION#${data.id}` },
        gsi2pk: { default: (data) => `USER#${data.userId}` },
        gsi2sk: {
            default: (data) => `LAST_MESSAGE#${data.lastMessageAt.toISOString()}`,
        },
        id: { type: "string", required: true, default: () => (0, uuid_1.v4)() },
        userId: { type: "string", required: true },
        agentId: { type: "string", required: true },
        agentType: {
            type: "string",
            required: true,
            validate: (value) => ["human", "ai"].includes(value),
        },
        title: { type: "string", required: true },
        messages: { type: "list", required: true },
        status: {
            type: "string",
            required: true,
            validate: (value) => ["active", "completed", "archived"].includes(value),
            default: "active",
        },
        trustScore: { type: "number" },
        createdAt: { type: "date", required: true, default: () => new Date() },
        updatedAt: { type: "date", required: true, default: () => new Date() },
        lastMessageAt: { type: "date", required: true, default: () => new Date() },
        metadata: { type: "map" },
    },
});
