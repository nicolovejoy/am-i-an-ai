"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRandomToken = exports.verifyToken = exports.generateToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
/**
 * Generate a JWT token for a user
 */
const generateToken = (user) => {
    const payload = {
        id: user.id,
        email: user.email,
        role: user.role,
    };
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error("JWT_SECRET is not defined in environment variables");
    }
    const options = {};
    // Handle expires in
    if (process.env.JWT_EXPIRES_IN) {
        // Type assertion to tell TypeScript this string has the right format
        options.expiresIn = process.env
            .JWT_EXPIRES_IN;
    }
    else {
        options.expiresIn = "7d"; // Default
    }
    // Fix type issue by using Buffer.from
    const secretBuffer = Buffer.from(secret, "utf-8");
    return jsonwebtoken_1.default.sign(payload, secretBuffer, options);
};
exports.generateToken = generateToken;
/**
 * Verify and decode a JWT token
 */
const verifyToken = (token) => {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error("JWT_SECRET is not defined in environment variables");
    }
    // Fix type issue by using Buffer.from
    const secretBuffer = Buffer.from(secret, "utf-8");
    return jsonwebtoken_1.default.verify(token, secretBuffer);
};
exports.verifyToken = verifyToken;
/**
 * Generate a random token for email verification or password reset
 */
const generateRandomToken = () => {
    return (Math.random().toString(36).substring(2, 15) +
        Math.random().toString(36).substring(2, 15));
};
exports.generateRandomToken = generateRandomToken;
