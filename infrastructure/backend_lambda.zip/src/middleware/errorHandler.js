"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationError = exports.errorHandler = void 0;
const errorHandler = (err, _req, res, _next) => {
    const statusCode = err.statusCode || 500;
    const isOperational = err.isOperational || false;
    // Log error
    console.error(`[ERROR] ${err.message}`);
    if (!isOperational) {
        console.error(err.stack);
    }
    // Respond to client
    res.status(statusCode).json({
        status: "error",
        message: err.message,
        stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
    });
};
exports.errorHandler = errorHandler;
// Custom error class for application errors
class ApplicationError extends Error {
    statusCode;
    isOperational;
    constructor(message, statusCode = 400, isOperational = true) {
        super(message);
        this.statusCode = statusCode;
        this.isOperational = isOperational;
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.ApplicationError = ApplicationError;
