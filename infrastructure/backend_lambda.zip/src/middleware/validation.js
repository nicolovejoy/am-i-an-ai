"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateParams = exports.validateQuery = exports.validateBody = void 0;
/**
 * Validates request body against a Zod schema
 */
const validateBody = (schema) => {
    return (req, res, next) => {
        try {
            schema.parse(req.body);
            next();
        }
        catch (error) {
            res.status(400).json({
                status: "error",
                message: "Validation failed",
                errors: error.errors,
            });
        }
    };
};
exports.validateBody = validateBody;
/**
 * Validates request query parameters against a Zod schema
 */
const validateQuery = (schema) => {
    return (req, res, next) => {
        try {
            schema.parse(req.query);
            next();
        }
        catch (error) {
            res.status(400).json({
                status: "error",
                message: "Validation failed",
                errors: error.errors,
            });
        }
    };
};
exports.validateQuery = validateQuery;
/**
 * Validates request params against a Zod schema
 */
const validateParams = (schema) => {
    return (req, res, next) => {
        try {
            schema.parse(req.params);
            next();
        }
        catch (error) {
            res.status(400).json({
                status: "error",
                message: "Validation failed",
                errors: error.errors,
            });
        }
    };
};
exports.validateParams = validateParams;
