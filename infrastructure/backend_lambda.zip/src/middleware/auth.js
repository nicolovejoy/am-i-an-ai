"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorize = exports.authenticate = void 0;
const auth_1 = require("../utils/auth");
const errorHandler_1 = require("./errorHandler");
const userRepository = __importStar(require("../repositories/userRepository"));
/**
 * Authentication middleware that verifies JWT token in the request header
 */
const authenticate = async (req, res, next) => {
    try {
        // Get token from Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            throw new errorHandler_1.ApplicationError("Unauthorized - No token provided", 401);
        }
        // Extract the token
        const token = authHeader.split(" ")[1];
        // Verify the token
        const decoded = (0, auth_1.verifyToken)(token);
        // Check if user exists in database
        const user = await userRepository.findById(decoded.id);
        if (!user) {
            throw new errorHandler_1.ApplicationError("Unauthorized - User not found", 401);
        }
        // Add user information to request
        req.user = decoded;
        next();
    }
    catch (error) {
        next(new errorHandler_1.ApplicationError("Unauthorized - Invalid token", 401));
    }
};
exports.authenticate = authenticate;
/**
 * Role-based authorization middleware
 */
const authorize = (roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return next(new errorHandler_1.ApplicationError("Unauthorized", 401));
        }
        if (!roles.includes(req.user.role)) {
            return next(new errorHandler_1.ApplicationError("Forbidden - Insufficient permissions", 403));
        }
        next();
    };
};
exports.authorize = authorize;
