"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.aiService = exports.AIService = void 0;
const openai_1 = __importDefault(require("openai"));
const config_1 = require("../config");
// Initialize OpenAI client
const openai = new openai_1.default({
    apiKey: process.env.OPENAI_API_KEY || config_1.config.openai.apiKey,
});
/**
 * Service to handle interactions with OpenAI's API
 */
class AIService {
    /**
     * Generate a chat completion response from OpenAI
     */
    async generateChatCompletion(request) {
        try {
            // Default model if not specified
            const model = request.model || "gpt-3.5-turbo";
            const response = await openai.chat.completions.create({
                model,
                messages: request.messages,
                temperature: 0.7,
                max_tokens: 500,
            });
            // Extract the response message
            const responseMessage = response.choices[0]?.message;
            if (!responseMessage) {
                throw new Error("No response from the AI model");
            }
            return {
                message: {
                    role: responseMessage.role,
                    content: responseMessage.content || "",
                },
            };
        }
        catch (error) {
            console.error("Error generating AI response:", error);
            throw error;
        }
    }
}
exports.AIService = AIService;
// Export singleton instance
exports.aiService = new AIService();
