"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ANALYSIS_TABLE = exports.CONVERSATION_TABLE = exports.USER_TABLE = exports.dynamoDb = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
// Load environment variables from .env file
dotenv_1.default.config({ path: path_1.default.resolve(__dirname, "../../.env") });
// Create a DynamoDB client based on environment
const client = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || "us-east-1",
    ...(process.env.DYNAMODB_ENDPOINT
        ? {
            endpoint: process.env.DYNAMODB_ENDPOINT,
            credentials: {
                accessKeyId: process.env.AWS_ACCESS_KEY_ID || "localkey",
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "localsecret",
            },
        }
        : {}),
});
// Create a DynamoDB Document client
exports.dynamoDb = lib_dynamodb_1.DynamoDBDocumentClient.from(client, {
    marshallOptions: {
        convertEmptyValues: true,
        removeUndefinedValues: true,
    },
});
// Table names from environment variables or defaults
exports.USER_TABLE = process.env.DYNAMODB_USER_TABLE || "amianai-users";
exports.CONVERSATION_TABLE = process.env.DYNAMODB_CONVERSATION_TABLE || "amianai-conversations";
exports.ANALYSIS_TABLE = process.env.DYNAMODB_ANALYSIS_TABLE || "amianai-analyses";
