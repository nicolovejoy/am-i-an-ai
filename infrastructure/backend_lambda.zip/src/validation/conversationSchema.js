"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.conversationIdSchema = exports.toggleArchiveSchema = exports.addMessageSchema = exports.createConversationSchema = void 0;
const zod_1 = require("zod");
// Schema for creating a new conversation
exports.createConversationSchema = zod_1.z.object({
    title: zod_1.z.string().min(1, "Title is required").max(100, "Title is too long"),
    initialMessage: zod_1.z.string().optional(),
});
// Schema for adding a message to a conversation
exports.addMessageSchema = zod_1.z.object({
    content: zod_1.z.string().min(1, "Message content is required"),
    sender: zod_1.z.enum(["user", "ai", "system"]),
});
// Schema for toggling archive status
exports.toggleArchiveSchema = zod_1.z.object({
    archived: zod_1.z.boolean(),
});
// Schema for conversation ID parameter
exports.conversationIdSchema = zod_1.z.object({
    id: zod_1.z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid conversation ID"),
});
