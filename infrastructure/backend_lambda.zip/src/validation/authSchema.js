"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateProfileSchema = exports.loginSchema = exports.registerSchema = void 0;
const zod_1 = require("zod");
// Schema for user registration
exports.registerSchema = zod_1.z.object({
    name: zod_1.z
        .string()
        .min(2, "Name must be at least 2 characters long")
        .max(50, "Name cannot exceed 50 characters"),
    email: zod_1.z.string().email("Please provide a valid email address"),
    password: zod_1.z
        .string()
        .min(8, "Password must be at least 8 characters long")
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"),
});
// Schema for user login
exports.loginSchema = zod_1.z.object({
    email: zod_1.z.string().email("Please provide a valid email address"),
    password: zod_1.z.string().min(1, "Password is required"),
});
// Schema for updating user profile
exports.updateProfileSchema = zod_1.z
    .object({
    name: zod_1.z
        .string()
        .min(2, "Name must be at least 2 characters long")
        .max(50, "Name cannot exceed 50 characters")
        .optional(),
    password: zod_1.z
        .string()
        .min(8, "Password must be at least 8 characters long")
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character")
        .optional(),
    currentPassword: zod_1.z.string().optional(),
})
    .refine((data) => {
    // If password is provided, currentPassword must also be provided
    return !data.password || data.currentPassword;
}, {
    message: "Current password is required to change the password",
    path: ["currentPassword"],
});
