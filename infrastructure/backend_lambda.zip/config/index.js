"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.config = {
    server: {
        port: process.env.PORT || 3001,
    },
    openai: {
        apiKey: process.env.OPENAI_API_KEY || "",
    },
    cors: {
        origin: process.env.FRONTEND_URL || "http://localhost:3000",
        credentials: true,
    },
};
