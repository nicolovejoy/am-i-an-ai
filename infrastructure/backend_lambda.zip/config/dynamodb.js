"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.documentClient = exports.client = exports.USER_TABLE = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Configuration options for DynamoDB client
const clientConfig = {
    region: process.env.AWS_REGION || "us-east-1",
};
// Use local DynamoDB endpoint if specified
if (process.env.DYNAMODB_ENDPOINT) {
    clientConfig.endpoint = process.env.DYNAMODB_ENDPOINT;
}
// Use AWS credentials if provided
if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
    clientConfig.credentials = {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    };
}
// Create the DynamoDB client
const client = new client_dynamodb_1.DynamoDBClient(clientConfig);
exports.client = client;
// Create a document client (makes working with DynamoDB easier)
const documentClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
exports.documentClient = documentClient;
// Table name from environment variable
exports.USER_TABLE = process.env.DYNAMODB_USER_TABLE || "amianai-users";
